KUICS Study Forensic Repository
==============================================================================

2.  OS + Windows Theory (1)		- Kernel Introduction, Memory Structure, Windows Process, User & Kernel Mode Introduction

References

https://ko.wikipedia.org/wiki/%EC%9A%B4%EC%98%81_%EC%B2%B4%EC%A0%9C
https://en.wikipedia.org/wiki/Protection_ring<br>
https://ko.wikipedia.org/wiki/%ED%8E%98%EC%9D%B4%EC%A7%95<br>
https://msdn.microsoft.com/ko-kr/library/windows/desktop/aa813706(v=vs.85).aspx<br>
https://msdn.microsoft.com/ko-kr/library/windows/desktop/ms686708(v=vs.85).aspx<br>
https://docs.microsoft.com/en-us/windows-hardware/drivers/gettingstarted/user-mode-and-kernel-mode