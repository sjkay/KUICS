KUICS Study Forensic Repository
==============================================================================

7.  Windows Prefetch Analysis	- Prefetch Analysis with Tool ( WinPrefetchView )

Downloads <br>
http://www.nirsoft.net/utils/win_prefetch_view.html<br>