KUICS Study Forensic Repository
==============================================================================

5.  Windows Theory (2) 			- Disk, Windows Cache, Event Log, ..., etc.

References
https://ko.wikipedia.org/wiki/%ED%8C%8C%EC%9D%BC_%EC%8B%9C%EC%8A%A4%ED%85%9C<br>
http://www.ntfs.com/ntfs-mft.htm<br><br>

Downloads
http://www.disk-editor.org/<br>