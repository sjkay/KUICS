KUICS Study Forensic Repository
==============================================================================

4.  Windows Dump Analysis (2) 	- Practice With Example 2

References

https://en.wikipedia.org/wiki/Core_dump
http://www.codeengn.com/archive/Forensic/Volatility%20Plugin%20%EC%9D%84%20%EC%9D%B4%EC%9A%A9%ED%95%9C%20Windows%20Memory%20Dump%20%EB%B6%84%EC%84%9D%20%5BDeok9%5D.pdf<br>
https://github.com/volatilityfoundation/volatility<br>
<br>

Downloads

https://drive.google.com/file/d/0B7Llj1y13UeaMXNxdjBzQ2o1eW8/view?usp=sharing<br>
http://www.volatilityfoundation.org/26