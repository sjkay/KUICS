KUICS Study Forensic Repository
==============================================================================

6.  Windows Registry (1) 		- What is Registry?