KUICS Study Forensic Repository
==============================================================================

Course ( It can be changed )
----------------

1.  What is Forensic?
2.  Windows Theory (1)			- Kernel Introduction, Memory Structure, Windows Process, User & Kernel Mode Introduction
3.	Windows Dump Analysis (1) 	- Practice With Example 1 ( KUICS Wargame )
4.  Windows Dump Analysis (2) 	- Practice With Example 2
5.  Windows Theory (2) 			- Disk, Windows Cache, Event Log, ..., etc.
6.  Windows Registry (1) 		- What is Registry?
7.  Windows Prefetch Analysis	- Prefetch Analysis with Tool ( WinPrefetchView )
8.  Windows Registry (2)		- Practice With Example : Tracking User Activity
9.  Misc						- Advanced (PE64, Kernel API, etc.), Other Things