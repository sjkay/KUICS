KUICS Study Forensic Repository
==============================================================================

9.  Misc		- Advanced (PE64, Kernel API, etc.), Other Things